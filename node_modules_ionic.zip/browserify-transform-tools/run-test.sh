    ./node_modules/.bin/mocha --compilers coffee:coffee-script -c --reporter spec $*
