module.exports = {
    color: "green"
};