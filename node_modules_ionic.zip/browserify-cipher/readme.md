browserify-cipher
===

[![Build Status](https://travis-ci.org/crypto-browserify/browserify-cipher.svg)](https://travis-ci.org/crypto-browserify/browserify-cipher)

Provides createCipher, createDecipher, createCipheriv, createDecipheriv and
getCiphers for the browserify.  Includes AES and DES ciphers.
