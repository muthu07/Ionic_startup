// this module should return something

module.exports = {
	foo: 'bar'
};
