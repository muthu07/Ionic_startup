t.deepEqual(require('./a.js'), { a: 5, b: 3 });
