// FILE F THREE
var G = require('./g.js');
module.exports = function () { return 111 * G };
