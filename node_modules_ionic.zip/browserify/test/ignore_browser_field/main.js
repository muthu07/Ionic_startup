console.log(require('a'));
console.log(require('b'));
