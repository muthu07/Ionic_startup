var foo = require('./foo');
assert.equal(foo, 'foo');
done();
