module.exports = function (s) { return s.toUpperCase() + '!' };
