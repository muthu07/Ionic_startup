# lodash._basefor v3.0.3

The internal [lodash](https://lodash.com/) function `baseFor` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash._basefor
```

In Node.js:
```js
var baseFor = require('lodash._basefor');
```

See the [package source](https://github.com/lodash/lodash/blob/3.0.3-npm-packages/lodash._basefor) for more details.
