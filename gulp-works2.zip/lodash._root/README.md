# lodash._root v3.0.1

The internal [lodash](https://lodash.com/) function `root` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash._root
```

In Node.js:
```js
var root = require('lodash._root');
```

See the [package source](https://github.com/lodash/lodash/blob/3.0.1-npm-packages/lodash._root) for more details.
