/*
 * Copyright (c) 2012 Trent Mick. All rights reserved.
 *
 * node-ansidiff test suite.
 */

var test = require('tap').test;
var ansidiff = require('../lib/ansidiff');


test('XXX', function (t) {
  t.end();
});
