**Note: for support questions, please use one of these channels:**

https://forum.ionicframework.com/
http://ionicworldwide.herokuapp.com/

**Note: for build related issues you can open up an issue on the ionic-app-scripts repo**

https://github.com/driftyco/ionic-app-scripts

Please ensure that you are on the latest version of the CLI.
`npm view ionic@latest version`

#### Short description of the problem:


#### What behavior are you expecting?


**Steps to reproduce:**
1.
2.
3.

```
insert any relevant code between the above and below backticks
```

**Post the output of `ionic info` below please**


**Other information:** (e.g. stacktraces, related issues, suggestions how to fix, stackoverflow links, forum links, etc)
