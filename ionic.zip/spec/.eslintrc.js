module.exports = {
  env: {
    jasmine: true
  },
  rules: {
    'no-underscore-dangle': 0
  }
};
