module.exports = {
  env: {
    node: true,
    jasmine: true
  }
};
