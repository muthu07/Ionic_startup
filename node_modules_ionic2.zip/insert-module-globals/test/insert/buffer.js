require('./foo/buf');
