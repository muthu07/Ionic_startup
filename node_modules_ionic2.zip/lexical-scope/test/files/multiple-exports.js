exports.foo = function () {
  return bar;
};
exports.bar = function (bar) {
  return bar;
};