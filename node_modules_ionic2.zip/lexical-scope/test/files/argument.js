function foo () {
    var a;
    return function (c) {
        a = c;
    };
}
