var Config = require('../lib/config');

describe('Config', function() {

  it('should have Config defined', function() {
    expect(Config).toBeDefined();
  });
});
