var convert = require('./convert'),
    func = convert('isRegExp', require('../isRegExp'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
