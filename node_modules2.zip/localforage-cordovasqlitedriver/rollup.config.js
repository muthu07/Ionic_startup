import babel from 'rollup-plugin-babel';

export default {
  entry: 'lib/localforage-cordovasqlitedriver.js',
  // sourceMap: true,
  plugins: [babel()]
};
