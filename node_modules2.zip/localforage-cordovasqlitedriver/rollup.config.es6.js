import config from './rollup.config';

config.format = 'es6';
config.dest = 'dist/localforage-cordovasqlitedriver.es6.js';

export default config;
