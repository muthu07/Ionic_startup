module.exports = function(source) {
	return source + "-simple";
};
