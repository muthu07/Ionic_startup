exports.pitch = function(remainingRequest) {
	this.addDependency("remainingRequest:" + remainingRequest);
};
