module.exports = function(source) {
	return Promise.resolve(source + "-promise-simple");
};
