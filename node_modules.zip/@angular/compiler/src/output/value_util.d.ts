import * as o from './output_ast';
export declare function convertValueToOutputAst(value: any, type?: o.Type): o.Expression;
